import syntaxtree.Node;
import visitor.TypeEvalVisitor;

public class P4 {

	public static void main(String[] args) throws Exception {
		
		new MiniSchemeParser(System.in);
		Node root = MiniSchemeParser.Goal();
		
		
		try{
			System.out.println(root.accept(new TypeEvalVisitor()));
		}catch(Exception e){
			System.err.println("Exception in executing..");
		
		}catch(Error e){
			System.err.println("error in executing..");
		
		}
		//Store.printMap();
	}

}