package store;

import java.util.HashMap;
import java.util.Map;


public class Store {
	public final static Type intType = new Type("int");
	public final static Type boolType = new Type("boolean");
	public static Type voidType = new Type("void");
	
	public final static Map<String, Type> typeMap = new HashMap<String, Type>();
	
	private static int idCount = 0;
	
	public static boolean addToMap(String key, Type tp){
		tp.setName(key);
		
		if(typeMap.containsKey(key)){
			return false;
		}else {
			typeMap.put(key, tp);
			return true;
		}
	}
	
	public static Type getType(String key){
		return typeMap.get(key);
	}

	public static Type updateType(Type oldTp, Type newTp){
		Type _ret = oldTp;
		oldTp.update(newTp);
		// this is actually the updated type
		return _ret;
	}
	public static Type addIdentifier(String name) {
		if(typeMap.containsKey(name)){
			return typeMap.get(name);
		
		}else {
			++idCount;
			Type tp = new Type("t"+idCount);
			tp.setName(name);
			typeMap.put(name, tp);
			return tp;
		}
	}

	public static void printMap() {
		for(String str : typeMap.keySet()){
			System.out.println("{"+str+" : "+typeMap.get(str)+"}");
		}
		
	}
}
