package store;

public class Type {
	private String name;
	
	private Type arg;
	private Type ret;
	
	private String type;
	private boolean isPrimary;
	
	public Type() {
		
	}
	
	public Type(Type  a, Type r) {
		setArg(a);
		setRet(r);
		this.isPrimary = false;
	}
	
	public Type(String t){
		setType(t);
		this.isPrimary = true;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Type getArg() {
		return arg;
	}

	public void setArg(Type arg) {
		this.arg = arg;
	}

	public Type getRet() {
		if(isPrimary){	return new Type(getType()); }
		return ret;
	}

	public void setRet(Type ret) {
		if(isPrimary) {	setType(ret.toString()); }
		this.ret = ret;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isPrimary() {
		return isPrimary;
	}
	
	@Override
	public String toString() {
		if(this.isPrimary){
			return this.getType();
			
		}else if((this.arg == null) && this.ret != null){
			return this.ret.toString();
			
		}else if((this.ret == null) && this.arg != null){
			return this.arg.toString();
			
		}else if(this.ret != null && this.arg != null){
			return "("+this.arg.toString()+"->"+this.ret.toString()+")";
		}else {
			return "{}";
		}
	}

	public void update(Type newTp) {
		if(isPrimaryData()){
			return;
		}
		this.arg = newTp.arg;
		this.isPrimary = newTp.isPrimary;
		this.ret = newTp.ret;
		this.type = newTp.type;
		
	}

	private boolean isPrimaryData() {
		return ( this.isPrimary && 
				 (this.type.equals(Store.intType) || this.type.equals(Store.boolType) || this.type.equals(Store.voidType))
			   );
	}
}
