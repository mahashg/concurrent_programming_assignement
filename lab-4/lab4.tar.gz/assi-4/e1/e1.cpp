#include <iostream>
#include <pthread.h>
# define MAX_CARS 3

using namespace std;

// HIGHWAY RELATED
int no_cars;
int dir;

// LOCK VARIABLE
pthread_mutex_t global_lock;
pthread_mutex_t print_lock;

// CAR
struct car {
	int dir;
	int id;
};

typedef struct car car;

void arrive(int dir_param){
	
	while(true){
		pthread_mutex_lock(&global_lock);
		if(no_cars == 0){
				++no_cars;
				dir = dir_param;
			pthread_mutex_unlock(&global_lock);
			break;
		}
		else if(dir_param != dir){
			pthread_mutex_unlock(&global_lock);
			pthread_cond_wait(&dir_var);
		}
		else {
			if(no_cars >= MAX_CARS){
				pthread_mutex_unlock(&global_lock);
				pthread_cond_wait(&no_car_var);
			}else {
					++no_cars;
				pthread_mutex_unlock(&global_lock);
				break;
			}
		}
	}// end of WHILE
}

void crossbridge(){
	
}

void exit(int dir){
	pthread_mutex_lock(&global_lock);
		--no_cars;
		pthread_cond_signal(&no_car_var);		
		if(no_cars == 0){
			pthread_cond_signal(&dir_var);
		}
	pthread_mutex_unlock(&global_lock);	
}

void* run(void* arg){

	car c = *((car *) arg);
	
	pthread_mutex_lock(&print_lock);
		cout<<"car "<<c.id<<" approached to cross the bridge."<<endl;
	pthread_mutex_unlock(&print_lock);
	
	arrive(c.dir);
	
	pthread_mutex_lock(&print_lock);
		cout<<"car "<<c.id<<" has started to cross the bridge."<<endl;
	pthread_mutex_unlock(&print_lock);
	
	crossbridge();
	
	pthread_mutex_lock(&print_lock);
		cout<<"car "<<c.id<<" has finished crossing to cross the bridge."<<endl;
	pthread_mutex_unlock(&print_lock);
	
	exit(c.dir);
	
	return NULL;
}

void init(){
	// INIT MUTEX LOCK VARIABLE
	pthread_mutex_init(&global_lock, NULL);
	pthread_mutex_init(&print_lock, NULL);
	
	// RANDOM VARIABLE
	
}
int main(){
	init();
	int total_cars = 50;
	
	pthread_t* threadArr;
	threadArr = new pthread_t[total_cars];
	
	cout<<"Processing begins. "<<endl;
	for(int i=0 ; i<total_cars ; ++i){
		car c;
		c.id = i+1;
		c.id = rand() % 2;
		pthread_create(&threadArr[i], NULL, *run, c);
	}
	
	for(int i=0 ; i<no_cars ; ++i){
		pthread_join(threadArr[i], NULL);
	}
	cout<<"End of Processing.. "<<endl;
	return 0;
}
