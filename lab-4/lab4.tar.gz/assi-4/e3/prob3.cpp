#include <iostream>
#include <pthread.h>
#include<sys/time.h>
#include <cstdlib>
#include <cmath>

using namespace std;

const int NUM_FRIENDS = 4;
const int MAX_NUM_SECONDS = 120;
const int CHECK_INTERVAL = 2;
const int SLEEP_INTERVAL = 10;
const int UPDATE_FREQUENCY = CHECK_INTERVAL * 1000 / SLEEP_INTERVAL;

int zombie_count[NUM_FRIENDS];
bool full = false;
bool empty = false;
bool one_has_exited = false;
int n;

pthread_mutex_t full_lock;
pthread_mutex_t empty_lock;
pthread_mutex_t exit_lock;
pthread_mutex_t count_lock[NUM_FRIENDS];

pthread_cond_t open_door;
pthread_cond_t not_empty;

class ZombieFighter
{
  public:
    int id;
    ZombieFighter(int id) {
        this->id = id;
    }
    virtual ~ZombieFighter() {}
};

void* friend_execute(void *arg){
    struct timeval start, curr;

    srand(time(NULL));

    gettimeofday(&start, NULL);

    ZombieFighter *current_fighter = (ZombieFighter *) arg;
    // cout << "friend_execute" << endl;
    // cout << "current_fighter->id: " << current_fighter->id << endl;

    // Update current_time_segment after every SLEEP_INTERVAL
    // microseconds
    int current_time_segment = 0;

    do {
        pthread_mutex_lock(&full_lock);
        if (full){
            // cout << current_fighter->id << ": Waiting on open_door" << endl;
            pthread_mutex_lock(&exit_lock);
            if (one_has_exited){
                return NULL;
            }
            pthread_mutex_unlock(&exit_lock);

            pthread_cond_wait(&open_door, &full_lock);
            // cout << "Woken up by open_door" << endl;
        }
        // TODO: Should we unlock full_lock? Can the acquiring of two locks
        // cause deadlock somehow? (Here, I chose to unlock full_lock)
        pthread_mutex_unlock(&full_lock);

        // Probability: 1/10
        if (rand() % 10 == 0){
            pthread_mutex_lock(&count_lock[current_fighter -> id]);
            zombie_count[current_fighter -> id]++;
            cout << current_fighter -> id << ": Zombie allowed in" << endl;
            pthread_mutex_unlock(&count_lock[current_fighter -> id]);

            // TODO: I should probably do this outside by checking if
            // there have been new zombies since the last time Main
            // Guy checked on this Friend.
            pthread_mutex_lock(&empty_lock);
            if (empty){
                cout << current_fighter -> id << ": Signal not_empty" << endl;
                pthread_cond_signal(&not_empty);
                empty = false;
            }
            pthread_mutex_unlock(&empty_lock);
        }

        usleep(SLEEP_INTERVAL * 1000);
        current_time_segment++;
        gettimeofday(&curr, NULL);
        cout << "curr.tv_sec - start.tv_sec: " << curr.tv_sec - start.tv_sec << endl;
    } while(curr.tv_sec - start.tv_sec < MAX_NUM_SECONDS);

    cout << "friend_execute: Out of while loop" << endl;

    pthread_mutex_lock(&empty_lock);
    if (empty){
        cout << current_fighter -> id << ": Signal not_empty" << endl;
        pthread_cond_signal(&not_empty);
        empty = false;
    }
    pthread_mutex_unlock(&empty_lock);

    pthread_mutex_lock(&exit_lock);
    one_has_exited = true;
    pthread_mutex_unlock(&exit_lock);
    
    return NULL;
}

/** 
 * @return number of zombies let inside by all friends
 */
int get_total_zombie_count(){
    int count = 0;
    for (int i = 0; i < NUM_FRIENDS; i++){
        pthread_mutex_lock(&count_lock[i]);
        count += zombie_count[i];
        pthread_mutex_unlock(&count_lock[i]);
    }
    cout << "Total zombie count updated" << endl;
    return count;
}

void* main_execute(void *arg){
    struct timeval start, curr;
    srand(time(NULL));
    gettimeofday(&start, NULL);

    ZombieFighter *current_fighter = (ZombieFighter *) arg;
    cout << "main_execute" << endl;
    cout << "current_fighter->id: " << current_fighter->id << endl;

    int number_zombies_killed = 0;

    // Update current_time_segment after every SLEEP_INTERVAL
    // microseconds
    int current_time_segment = 0;
    int total_let_in = 0;
    
    do {
        if (current_time_segment % UPDATE_FREQUENCY == 0){
            total_let_in = get_total_zombie_count();

            pthread_mutex_lock(&full_lock);

            if (!full and total_let_in - number_zombies_killed >= n){
                // Tell friends to stop letting in zombies
                full = true;
                cout << "full = true" << endl;
            }
            pthread_mutex_unlock(&full_lock);
        }

        pthread_mutex_lock(&full_lock);
        cout << "full: " << full << endl;
        cout << "total_let_in - number_zombies_killed: " << total_let_in - number_zombies_killed << endl;
        if (full and total_let_in - number_zombies_killed <= n/2){
            // Tell friends to resume letting zombies in
            full = false;
            cout << "open_door broadcasted" << endl;
            pthread_cond_broadcast(&open_door);
        }
        pthread_mutex_unlock(&full_lock);

        if (total_let_in - number_zombies_killed > 0){
            if (rand() % 10 < 4){
                // Kill zombie with probability: 4/10
                number_zombies_killed++;
                cout << current_fighter -> id << ": Zombie killed" << endl;
            }
        } else {
            // No zombies to kill
            // TODO: Else, set empty flag
            pthread_mutex_lock(&empty_lock);
            empty = true;

            pthread_mutex_lock(&exit_lock);
            if (one_has_exited){
                int throughput = number_zombies_killed / MAX_NUM_SECONDS;
                cout << "throughput: " << throughput << endl;
                return NULL;
            }
            pthread_mutex_unlock(&exit_lock);

            pthread_cond_wait(&not_empty, &empty_lock);
            cout << "No longer empty" << endl;
            pthread_mutex_unlock(&empty_lock);
            total_let_in = get_total_zombie_count();
        }

        cout << "total-number-zombies: " << total_let_in - number_zombies_killed << endl;

        usleep(SLEEP_INTERVAL * 1000);
        current_time_segment++;
        gettimeofday(&curr, NULL);
        cout << "curr.tv_sec - start.tv_sec: " << curr.tv_sec - start.tv_sec << endl;
        cout << "current_time_segment: " << current_time_segment << endl;
        // } while(current_time_segment < MAX_NUM_SECONDS * 1000 / SLEEP_INTERVAL);
    } while(curr.tv_sec - start.tv_sec < MAX_NUM_SECONDS);

    cout << "main_execute: Out of while loop" << endl;
    pthread_cond_broadcast(&open_door);

    pthread_mutex_lock(&exit_lock);
    one_has_exited = true;
    pthread_mutex_unlock(&exit_lock);

    int throughput = number_zombies_killed / MAX_NUM_SECONDS;
    cout << "throughput: " << throughput << endl;
    
    return NULL;
}

void print_parameters(){
    cout << "NUM_FRIENDS: " << NUM_FRIENDS << endl; 
    cout << "MAX_NUM_SECONDS: " << MAX_NUM_SECONDS << " seconds" << endl; 
    cout << "CHECK_INTERVAL: " << CHECK_INTERVAL << " seconds" << endl; 
    cout << "SLEEP_INTERVAL: " << SLEEP_INTERVAL << " ms" << endl; 
    cout << "UPDATE_FREQUENCY: " << UPDATE_FREQUENCY << " times per second" << endl; 
}

int main(int argc, char *argv[])
{
    if (argc == 2){
        n = atoi (argv[1]);
    } else {
        cout << "Args:\nn: Max number of zombies" << endl;
        exit (1);
    }

    // cout << "NUM_FRIENDS: " << NUM_FRIENDS << endl; 
    // cout << "MAX_NUM_SECONDS: " << MAX_NUM_SECONDS << " seconds" << endl; 
    // cout << "CHECK_INTERVAL: " << CHECK_INTERVAL << " seconds" << endl; 
    // cout << "SLEEP_INTERVAL: " << SLEEP_INTERVAL << " ms" << endl; 
    // cout << "UPDATE_FREQUENCY: " << UPDATE_FREQUENCY << " times per second" << endl; 
    // print_parameters();

    pthread_t threads[NUM_FRIENDS];
    pthread_t main_thread;

    for (int i = 0; i < NUM_FRIENDS; i++){
        zombie_count[i] = 0;
    }

    pthread_create(&main_thread, NULL, *main_execute, new ZombieFighter(100));

    for (int i = 0; i < NUM_FRIENDS; i++){
        pthread_create(&threads[i], NULL, *friend_execute, new ZombieFighter(i));
    }

    pthread_cond_init(&open_door, NULL);
    pthread_cond_init(&not_empty, NULL);
	
    for (int i = 0; i < NUM_FRIENDS; i++){
        pthread_join(threads[i], NULL);
    }

    pthread_join(main_thread, NULL);

    cout<<"end of processing..."<<endl;

    pthread_mutex_destroy(&full_lock);
    pthread_mutex_destroy(&empty_lock);
    pthread_mutex_destroy(&exit_lock);
    for (int i = 0; i < NUM_FRIENDS; i++){
        pthread_mutex_destroy(&count_lock[i]);
    }

    pthread_cond_destroy(&open_door);
    pthread_cond_destroy(&not_empty);

    pthread_exit(NULL);
    return 0;
}
