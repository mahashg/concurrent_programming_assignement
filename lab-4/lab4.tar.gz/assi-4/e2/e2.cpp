#include <iostream>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <list>

using namespace std;

// mutex variable
pthread_mutex_t list_lock;
pthread_mutex_t prnt_lock;

// condition variable
pthread_cond_t free_student;

int answered=-1;

class student {
public:
	int id;
	int total;
	int current;
	bool select;
	
	student(){
		id = 0 ; total = 0 ; current = 0;
	}
	student(int i, int t){
		id = i;		total = t;		current = 0;
	}
	void questionStart();
	void questionEnd();
};

class teacher {
public:	
	student std;
	
	teacher(){
	 
	}
	
	void answerStart();
	void answerEnd();
};

list<student> lst;

void student::questionStart(){

	pthread_mutex_lock(&list_lock);
		lst.push_back((*this));
	pthread_mutex_unlock(&list_lock);
	
	pthread_cond_signal(&free_student);
	// wait while your professor selects you
	while(true){
		bool temp = select;
		if(!temp)
			break;
	}
	pthread_yield();
}

void student::questionEnd(){
	while(true){
		pthread_mutex_lock(&list_lock);
		int temp = answered;		
		
		if(temp == id){
			answered = -1;
	
		    pthread_mutex_unlock(&list_lock);
		    break;
		}
		pthread_mutex_unlock(&list_lock);
	}
	select = false;
	
	pthread_yield();
}

void teacher::answerStart(){
	
	// wait until you have a student
	while(true){
	    pthread_mutex_lock(&list_lock);
	    if(lst.empty()){
		    pthread_cond_wait(&free_student, &list_lock);
		    pthread_mutex_unlock(&list_lock);
	    }else {
		    pthread_mutex_unlock(&list_lock);
	    }
	
	    pthread_mutex_lock(&list_lock);	
	        if(!lst.empty()){
		        std = lst.front();		
		        lst.pop_front();
		        std.select = true;
        	    pthread_mutex_unlock(&list_lock);
        	    break;
		    }
	    pthread_mutex_unlock(&list_lock);
	}
	pthread_yield();
}

void teacher::answerEnd(){
	
	int time_to_sleep = rand() % 13 + 2;
	usleep(time_to_sleep*100);			// 0.1 times time to sleep
	
      while(true){
		  pthread_mutex_lock(&list_lock);
			int temp = answered;
			if(temp == -1){
			  answered = std.id;
			  pthread_mutex_unlock(&list_lock);
			  break;
			}
		  pthread_mutex_unlock(&list_lock);	
      }
      pthread_yield();
}


void* runTeacher(void* arg){
	teacher t = *((teacher*) arg);
	while(true){
		
		pthread_mutex_lock(&prnt_lock);	
			cout<<"teacher is free.. going for power nap."<<endl;
		pthread_mutex_unlock(&prnt_lock);
		
		t.answerStart();

		pthread_mutex_lock(&prnt_lock);
			cout<<"teacher is answering ("<<t.std.id<<", "<<t.std.current<<") question."<<endl;
		pthread_mutex_unlock(&prnt_lock);	

		t.answerEnd();
		
		pthread_mutex_lock(&prnt_lock);
			cout<<"teacher has finished answering ("<<t.std.id<<", "<<t.std.current<<") question."<<endl;
		pthread_mutex_unlock(&prnt_lock);
	}
	return NULL;
}

void* runStudent(void* arg){
	student s = *((student *)arg);
	
	while(s.current < s.total){
		
		pthread_mutex_lock(&prnt_lock);
			cout<<"student ("<<s.id<<", "<<s.current<<") is waiting to ask the question."<<endl;
		pthread_mutex_unlock(&prnt_lock);
		
		s.questionStart();

		pthread_mutex_lock(&prnt_lock);
			cout<<"student is asking ("<<s.id<<", "<<s.current<<")."<<endl;
		pthread_mutex_unlock(&prnt_lock);

		s.questionEnd();
		
		pthread_mutex_lock(&prnt_lock);
			cout<<"student ("<<s.id<<", "<<s.current<<") has finished asking question."<<endl;
		pthread_mutex_unlock(&prnt_lock);
		s.current++;
	}
	
	return NULL;
}

void init(){
	pthread_mutex_init(&list_lock, NULL);
	pthread_mutex_init(&prnt_lock, NULL);
	pthread_cond_init(&free_student, NULL);
}

int main(){
	init();
	int no_student = 30;
	pthread_t thread_teacher;
	pthread_create(&thread_teacher, NULL, *runTeacher, (void*)(new teacher()));
	
	pthread_t* threadArr;
	threadArr = new pthread_t[no_student];
	for(int i=0 ; i<no_student ; ++i){		
		pthread_create(&threadArr[i], NULL, *runStudent, (void*)(new student(i+1, rand()%10)));
	}
	
	for(int i=0 ; i<5 ; ++i){
		pthread_join(threadArr[i], NULL);
	}
	cout<<"End of Processing.. "<<endl;
	return 0;
}
