1. The project has been developed on windows environment using visual studio IDE hence the deliverable contains .exe file.
2. Execution Requires following argument:
r - no of rows
c - no of columns
k - value range of orignal matrix
s - name of the file containing shuffle commands of form
	"R <r1> <r2>" or "C <c1> <c2>"
	(name should contain name + extension)
p - percentage of pixels to be selected for threshold.
	[actual no of candiates generated can be more than 10% in case they all have same value]
n - no of generations of game of life
out - name of the output file. 
     (it is, stored as .txt file)	